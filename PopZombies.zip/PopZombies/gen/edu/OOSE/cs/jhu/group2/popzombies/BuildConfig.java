/** Automatically generated file. DO NOT MODIFY */
package edu.OOSE.cs.jhu.group2.popzombies;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}